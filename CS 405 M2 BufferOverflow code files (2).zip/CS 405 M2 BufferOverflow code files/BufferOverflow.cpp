
// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iomanip>
#include <iostream>
#include <cstring>  // for handling overflow

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    // Inform user about input limit to prevent overflow
    std::cout << "Enter a value (max 19 characters): ";

    // Read up to 19 characters to ensure null-termination without overflow
    std::cin.get(user_input, sizeof(user_input));

    // Check if overflow occurred
    if (std::cin.gcount() == sizeof(user_input) - 1 && std::cin.peek() != '\n') {
        std::cout << "Warning: Input exceeds buffer limit and was truncated." << std::endl;
        // Clear the remaining characters from the input buffer
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    // Display user input and account number, with overflow prevention
    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}
